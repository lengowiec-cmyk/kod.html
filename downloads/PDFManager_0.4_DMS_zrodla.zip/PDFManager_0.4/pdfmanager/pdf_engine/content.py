"""Positioned text/image insertion with transactional saves and overflow validation."""
import pymupdf
from pdfmanager.pdf_engine.io_utils import mutate_pdf_file
from pdfmanager.pdf_engine.font_resolver import resolve_font

def insert_content_at(path,page_index,rect,*,text='',style=None,image=None,font_file=None):
    def mutate(doc):
        page=doc[page_index];box=pymupdf.Rect(rect)
        if box.is_empty or not page.rect.contains(box):
            raise ValueError('Obszar musi mieścić się w granicach strony. Zmniejsz rozmiar lub zmień pozycję.')
        # Convert displayed page coordinates to the unrotated content coordinate system.
        box=box*page.derotation_matrix
        if image:
            page.insert_image(box,stream=image,keep_proportion=True)
        else:
            if not text.strip():raise ValueError('Wpisz tekst lub wybierz obraz.')
            font=resolve_font(page,style.font_name,text,style.bold,style.italic)
            if font_file is not None:
                from pathlib import Path
                from pdfmanager.pdf_engine.font_resolver import ResolvedFont, _font_covers_text
                buffer=Path(font_file).read_bytes()
                if not _font_covers_text(buffer,text):raise ValueError('Czcionka nie obsługuje wszystkich znaków.')
                font=ResolvedFont('custom_insert',None,buffer,False)
            page.insert_font(fontname=font.fontname,fontbuffer=font.fontbuffer,fontfile=str(font.fontfile) if font.fontfile else None)
            remaining=page.insert_textbox(box,text,fontname=font.fontname,fontsize=style.font_size,color=tuple(c/255 for c in style.color_rgb))
            if remaining<0:raise ValueError('Tekst nie mieści się w polu. Powiększ pole lub zmniejsz czcionkę.')
    return mutate_pdf_file(path,mutate)
