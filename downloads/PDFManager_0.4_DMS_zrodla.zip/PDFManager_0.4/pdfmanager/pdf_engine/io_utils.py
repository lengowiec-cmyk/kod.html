"""Bezpieczny, atomowy zapis plików PDF — wspólny dla wszystkich silników.

Krytyczne dla Windows: nadpisanie pliku, który wciąż jest otwarty (ma aktywny
uchwyt) w tym samym procesie, zawodzi na Windows z błędem "plik jest używany
przez inny proces" (w przeciwieństwie do Linux/macOS, gdzie zwykle się to
udaje). Dlatego każda funkcja zapisu w tym module operuje na danych w
pamięci i nie wymaga, by wywołujący miał otwarty `pymupdf.Document` na
docelowej ścieżce w momencie zapisu — a warstwa UI (patrz `PdfViewerWidget`)
musi zamknąć swój własny uchwyt na plik PRZED wywołaniem funkcji silnika,
a otworzyć go ponownie PO zapisie.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, TypeVar

import pymupdf

T = TypeVar("T")


def atomic_write_bytes(path: Path, data: bytes) -> None:
    """Zapisuje `data` do `path` atomowo (plik tymczasowy + zamiana).

    Wywołujący powinien najpierw zserializować dokument do bajtów
    (``doc.tobytes(...)``) i ZAMKNĄĆ swój ``pymupdf.Document`` — dopiero
    potem wywołać tę funkcję. Patrz docstring modułu.
    """
    path = Path(path)
    tmp_path = path.with_name(path.name + ".tmp")
    tmp_path.write_bytes(data)
    tmp_path.replace(path)


def mutate_pdf_file(path: Path, mutate: Callable[[pymupdf.Document], T]) -> T:
    """Otwiera PDF z `path`, wywołuje `mutate(doc)`, zapisuje wynik atomowo.

    Standardowy wzorzec dla wszystkich operacji silnika PDF modyfikujących
    plik w miejscu (edycja tekstu, adnotacje, operacje na stronach):
    otwórz -> zmutuj w pamięci -> zserializuj -> ZAMKNIJ -> zapisz atomowo.
    """
    path = Path(path)
    doc = pymupdf.open(str(path))
    try:
        result = mutate(doc)
        data = doc.tobytes(garbage=3, deflate=True)
    finally:
        doc.close()
    atomic_write_bytes(path, data)
    return result


def new_pdf_file(path: Path, build: Callable[[pymupdf.Document], None]) -> None:
    """Tworzy nowy dokument PDF od zera, wypełnia go `build(doc)` i zapisuje atomowo."""
    doc = pymupdf.open()
    try:
        build(doc)
        data = doc.tobytes(garbage=3, deflate=True)
    finally:
        doc.close()
    atomic_write_bytes(path, data)
