"""Batch split without source modifications or overwriting outputs."""
from pathlib import Path
import tempfile
import pymupdf
from pdfmanager.pdf_engine.page_ops import split_at

def batch_split(paths,output_folder,pages_per_part=1):
    folder=Path(output_folder)
    if not folder.is_dir() or pages_per_part<1:raise ValueError('Wybierz folder i dodatnią liczbę stron na część.')
    results=[]
    for value in paths:
        source=Path(value)
        try:
            with pymupdf.open(source) as doc:
                if doc.needs_pass:raise ValueError('Dokument wymaga hasła.')
                count=len(doc)
            # Unique per-source folder keeps similarly named inputs and prior runs intact.
            destination=Path(tempfile.mkdtemp(prefix=source.stem+'_split_',dir=folder))
            try:outputs=split_at(source,list(range(pages_per_part-1,count-1,pages_per_part)),destination,source.stem)
            except Exception:
                import shutil
                shutil.rmtree(destination);raise
            results.append((source,outputs,None))
        except Exception as exc:results.append((source,[],str(exc)))
    return results

def transfer_file(source,destination,*,move=False):
    import shutil
    source=Path(source);destination=Path(destination)
    if source.resolve()==destination.resolve():raise ValueError('Plik źródłowy i docelowy są takie same.')
    # Exclusive copy works across Windows drives; source is removed only after success.
    with destination.open('xb') as target:
        try:
            with source.open('rb') as original:shutil.copyfileobj(original,target)
        except Exception:
            target.close();destination.unlink(missing_ok=True);raise
    try:shutil.copystat(source,destination)
    except OSError:pass
    if move:source.unlink()
    return destination
