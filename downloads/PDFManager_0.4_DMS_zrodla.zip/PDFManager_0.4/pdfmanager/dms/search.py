from pathlib import Path
from pdfmanager.pdf_engine.extended_ops import search_text

def search_files(folder,query,*,recursive=True,fulltext=False):
    folder=Path(folder)
    if not folder.is_dir() or not query.strip():raise ValueError('Wybierz folder i wpisz tekst.')
    results=[];errors=[]
    for path in sorted(folder.rglob('*') if recursive else folder.iterdir()):
        if not path.is_file():continue
        try:
            if query.casefold() in path.name.casefold():results.append((path,-1,1))
            if fulltext and path.suffix.lower()=='.pdf':
                for page,count in search_text(path,query):results.append((path,page,count))
        except Exception as exc:errors.append(f'{path.name}: {exc}')
    return results,errors
