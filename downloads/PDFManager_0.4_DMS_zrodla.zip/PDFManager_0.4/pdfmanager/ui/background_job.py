"""Run heavy exports off the GUI thread, retaining errors and worker lifetime."""
from PySide6.QtCore import QThread, Signal, QTimer, Qt
from PySide6.QtWidgets import QProgressDialog, QMessageBox


class Worker(QThread):
    succeeded=Signal(object)
    failed=Signal(str)
    def __init__(self, function, parent):
        super().__init__(parent);self.function=function
    def run(self):
        try:self.succeeded.emit(self.function())
        except Exception as exc:self.failed.emit(str(exc))


class BusyDialog(QProgressDialog):
    def reject(self):
        # Workers cannot be stopped midway through writing a PDF.
        pass
    def closeEvent(self,event):event.ignore()


def run_job(parent, title, function, on_success=None):
    dialog=BusyDialog(title, '', 0, 0, parent)
    dialog.setCancelButton(None);dialog.setWindowTitle(title)
    dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
    worker=Worker(function,parent)
    outcome={}
    worker.succeeded.connect(lambda result: outcome.update(result=result))
    worker.failed.connect(lambda error: outcome.update(error=error))
    worker.finished.connect(dialog.accept)
    QTimer.singleShot(0,worker.start)
    dialog.exec()
    # A window-manager close must not destroy a running thread.
    if worker.isRunning():
        dialog.exec()
    worker.wait()
    worker.deleteLater();dialog.deleteLater()
    if 'error' in outcome:
        QMessageBox.critical(parent,title,outcome['error']);return
    if on_success:on_success(outcome.get('result'))
